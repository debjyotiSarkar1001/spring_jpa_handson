package com.cognizant.ormlearn;

import java.sql.Date;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cognizant.ormlearn.model.Attempt;
import com.cognizant.ormlearn.model.AttemptOption;
import com.cognizant.ormlearn.model.AttemptQuestion;
import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.model.Department;
import com.cognizant.ormlearn.service.AttemptService;
import com.cognizant.ormlearn.service.CountryService;
import com.cognizant.ormlearn.service.exception.CountryNotFoundException;
import com.cognizant.ormlearn.model.Employee;
import com.cognizant.ormlearn.model.Skill;
import com.cognizant.ormlearn.service.EmployeeService;
import com.cognizant.ormlearn.service.SkillService;
import com.cognizant.ormlearn.model.Department;
import com.cognizant.ormlearn.service.DepartmentService;
import de.vandermeer.asciitable.AsciiTable;

@SpringBootApplication
public class OrmLearnApplication {
	
	private static CountryService countryService;
	private static EmployeeService employeeService;
	private static DepartmentService departmentService;
	private static AttemptService attemptService;

	private static SkillService skillService;
	private static final Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);
	
	public static void main(String[] args){
		ApplicationContext context = SpringApplication.run(OrmLearnApplication.class, args);
		countryService = context.getBean(CountryService.class);
		employeeService=context.getBean(EmployeeService.class);
		departmentService=context.getBean(DepartmentService.class);
		skillService=context.getBean(SkillService.class);
		attemptService=context.getBean(AttemptService.class);
		LOGGER.info("Inside main");
		 //testGetAttempt();
		 //testGetAttempt2();
		//testGetAllEmployeesNative();
		 //testGetAverageSalary();
		 //testGetAllPermanentEmployees();
		//testAddSkillToEmployee();
		//testGetEmployeeAlongWithSkills();
		//testGetDepartment();
		 //testUpdateEmployee();
		 //testAddEmployee();
		//testGetEmployee();
		//testGetAllCountries();
		//testGetCountriesByKeyword("B");
		//testFindCountryByCode("IN");
		Country country1 = new Country();
		country1.setCode("NV");
		country1.setName("New Ville");
		//testAddCountry(country1);
		//testUpdateCountry("NV","Netherland");
		//testDeleteCountry("NV");
	}
	private static void testGetAttempt() {
		Attempt attempt = attemptService.getAttempt(101, 1);
		System.out.println(attempt.toString());
	}
	private static void testGetAttempt2() {
		Attempt attempt = attemptService.getAttemptDetail(102, 2);
		Set<AttemptQuestion> attemptQuestions = attempt.getAttemptQuestion();
		for (AttemptQuestion attemptQuestion : attemptQuestions) {
			System.out.println(attemptQuestion.getQuestion().getTxt());
			Set<AttemptOption> attemptOptions = attemptQuestion.getAttemptOption();
			int i = 1;
			for (AttemptOption attemptOption : attemptOptions) {
				System.out.print(i + ")\t");
				System.out.print(attemptOption.getOptions().getText() + "\t");
				System.out.print(attemptOption.getOptions().getScore() + "\t");
				System.out.println(attemptOption.isSelected());
				i++;
			}
		}
	}
	private static void testGetAllEmployeesNative()
	{
		LOGGER.info("Start");
		List<Employee> employees=employeeService.getAllEmployeesNative();
		LOGGER.debug("Permanent Employees:{}",employees);
		LOGGER.info("End");

	}
	private static void testGetAverageSalary()
	{
		LOGGER.info("Start");
		double avgSalary=employeeService.getAverageSalary(101);
		LOGGER.debug("Average Salary of Employees:{}",avgSalary);
		LOGGER.info("End");
	
	}
	private static void testGetAllPermanentEmployees()
	{
	LOGGER.info("Start");
	List<Employee> employees=employeeService.getAllPermanentEmployees();
	LOGGER.debug("Permanent Employees:{}",employees);
	employees.forEach(e -> LOGGER.debug("Skills :{}",e.getSkillList()));
	LOGGER.info("End");
	}
	private static void testAddSkillToEmployee()
	{
		LOGGER.info("Start");
		Employee emp=employeeService.get(2);
		Skill skill=skillService.get(3);
		Set<Skill> skillList=emp.getSkillList();
		skillList.add(skill);
		employeeService.save(emp);
		LOGGER.info("End");
	
	}
	private static void testGetEmployeeAlongWithSkills()
	{
	LOGGER.info("Start");
	Employee emp=employeeService.get(3);
	System.out.println(emp);
	for(Skill s : emp.getSkillList())
	{
	System.out.println(s);
	}
	LOGGER.info("End");
	}
	private static void testGetDepartment()
	{
	LOGGER.info("Start");
	Department department=departmentService.get(101);
	System.out.println(department.getName());
	for(Employee e : department.getEmployeeList())
	{
	System.out.println(e);
	}
	LOGGER.info("End");

	}
	private static void testUpdateEmployee()
	{
		LOGGER.info("Start");
		Employee emp=new Employee();
		emp.setId(4);
		emp.setName("Saksham");
		emp.setSalary(100000.0);
		emp.setPermanent(false);
		String s="1998-05-21";
		Date d=Date.valueOf(s);
		emp.setDateOfBirth(d);
		Department department=departmentService.get(103);
		emp.setDepartment(department);
		employeeService.update(4, emp);
		LOGGER.info("End");

	}
	private static void testAddEmployee()
	{
		LOGGER.info("Start");
		Employee emp=new Employee();
		emp.setId(4);
		emp.setName("Ashray");
		emp.setSalary(1000.0);
		emp.setPermanent(false);
		String s="2018-10-19";
		Date d=Date.valueOf(s);
		emp.setDateOfBirth(d);
		Department department=departmentService.get(101);
		emp.setDepartment(department);
		employeeService.save(emp);
		LOGGER.info("End");

	}
	private static void testGetEmployee()
	{
	LOGGER.info("Start");
	Employee emp=employeeService.get(2);
	System.out.println(emp);
	LOGGER.info("End");
	}
	private static void testGetCountriesByKeyword(String keyword)
	{
		LOGGER.info("Start");
	    List<Country> countries=countryService.getCountriesByKeyword(keyword);
		AsciiTable at = new AsciiTable();
		at.addRule();
		at.addRow("S.No.","country_code","country_name");
        int i=1;
		for(Country c : countries) {
			at.addRule();
			at.addRow(i,c.getCode(),c.getName());
			i++;
		}
		System.out.println(at.render());

	}
	private static void testGetAllCountries() {
		LOGGER.info("Start");
		List<Country> countries = countryService.getAllCountries();
		AsciiTable at = new AsciiTable();
		at.addRule();
		at.addRow("S.No.","country_code","country_name");
        int i=1;
		for(Country c : countries) {
			at.addRule();
			at.addRow(i,c.getCode(),c.getName());
			i++;
		}
		System.out.println(at.render());
		LOGGER.debug("countries={}", countries);
		LOGGER.info("End");
	}
	
	private static void testFindCountryByCode(String countryCode) throws CountryNotFoundException {
		LOGGER.info("Start");
		Country country = countryService.findCountryByCode(countryCode);
		System.out.println(country);
		LOGGER.debug("Country:{}", country);
		LOGGER.info("End");
	}
	private static void testAddCountry(Country country1) throws CountryNotFoundException {
		countryService.addCountry(country1);
		
		Country country = countryService.findCountryByCode("NV");
		System.out.println(country);
	}
	public static void testUpdateCountry(String countryCode,String countryName) throws CountryNotFoundException {
		//New Ville -> Neverland
		countryService.updateCountry(countryCode,countryName);
	}
	
	public static void testDeleteCountry(String countryCode) {
		countryService.deleteCountry(countryCode);
	}
}
