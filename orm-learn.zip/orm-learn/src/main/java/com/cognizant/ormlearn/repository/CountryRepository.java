package com.cognizant.ormlearn.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import org.springframework.stereotype.Repository;
import com.cognizant.ormlearn.model.Country;
@Repository
public interface CountryRepository extends JpaRepository<Country,String> {
    @Query("select c from com.cognizant.ormlearn.model.Country c where c.name like %?1%")
	List<Country> findByPlaceContainingIgnoreCase(String place);
}
