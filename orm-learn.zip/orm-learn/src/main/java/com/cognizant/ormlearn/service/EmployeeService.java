package com.cognizant.ormlearn.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.ormlearn.model.Employee;
import com.cognizant.ormlearn.repository.EmployeeRepository;

@Service
public class EmployeeService {
   @Autowired	
   EmployeeRepository employeeRepository;
   @Transactional
   public Employee get(int id)
   {
   return employeeRepository.findById(id).get();
   }
   @Transactional
   public void save(Employee employee)
   {
	System.out.println("Employee Service Invoked");
	employeeRepository.save(employee);
   }
   @Transactional
   public void update(int empId,Employee employee)
   {
	Employee empToUpdate=employeeRepository.getOne(empId);
	empToUpdate.setName(employee.getName());
	empToUpdate.setSalary(employee.getSalary());
	empToUpdate.setPermanent(employee.isPermanent());
	empToUpdate.setDateOfBirth(employee.getDateOfBirth());
	empToUpdate.setDepartment(employee.getDepartment());
	employeeRepository.save(empToUpdate);
   }
   @Transactional
   public List<Employee> getAllPermanentEmployees()
   {
	return employeeRepository.getAllPermanentEmployees();
   }
   @Transactional
   public double getAverageSalary(int deptId)
   {
	 return employeeRepository.getAverageSalary(deptId);
   }
   @Transactional
   public List<Employee> getAllEmployeesNative()
   {
	return employeeRepository.getAllEmployeeNative(); 
   }

}
