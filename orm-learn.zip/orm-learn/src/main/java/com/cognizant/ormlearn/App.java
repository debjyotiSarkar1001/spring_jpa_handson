package com.cognizant.ormlearn;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import com.cognizant.ormlearn.model.Country;
import java.util.*;

import javax.persistence.Query;

import org.hibernate.Session;
public class App {

	public static void main(String[] args) {
		System.out.println("Project Started");
		Configuration configuration=new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session=sessionFactory.openSession();
		//List<Country> countries=session.createCriteria(Country.class).list();
		Query query=session.createQuery("FROM com.cognizant.ormlearn.model.Country");
		session.beginTransaction();
		List<Country> countries=query.getResultList();
		for(Country country:countries)
		{
		System.out.println(country);
		}
		Country countryObj=session.get(Country.class, new String("IN"));
		Country saObj=session.get(Country.class, new String("SA"));
		System.out.println("Country Obj... "+countryObj);
		Country engObj=new Country();
		//engObj.setCode("En");
		//engObj.setName("England");
		addCountry(engObj,session);
		deleteCountry(saObj,session);
		session.getTransaction().commit();
		session.close();
		sessionFactory.close();

	}
	public Country getCountry(String countryCode,Session session)
	{
	Country c=session.get(Country.class, new String(countryCode));
	return c;
	}
	public static void deleteCountry(Country countryObj,Session session)
	{
	session.delete(countryObj);
	System.out.println("Deleted country object successfully");
	}
	public static void addCountry(Country country,Session session)
	{
	session.save(country);
	System.out.println("Country Object Added successfully");
	}

}
