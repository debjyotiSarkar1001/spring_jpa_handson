package com.cognizant.ormlearn.model;
import java.util.*;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity
@Table(name="department")
public class Department 
{
@Id
@Column(name="dp_id")
@GeneratedValue(strategy=GenerationType.IDENTITY)
private int id;
@Column(name="dp_name")
private String name;
@OneToMany(mappedBy = "department", fetch = FetchType.EAGER, cascade=CascadeType.ALL)
private Set<Employee> employeeList;
public Set<Employee> getEmployeeList() {
	return employeeList;
}
public void setEmployeeList(Set<Employee> employeeList) {
	this.employeeList = employeeList;
}
public int getId() {
	return id;
}
@Override
public String toString() {
	return "Department [id=" + id + ", name=" + name + "]";
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
}
