package com.cognizant.ormlearn.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

import com.cognizant.ormlearn.model.Employee;
@Repository
public interface EmployeeRepository extends JpaRepository<Employee,Integer> {
@Query(value="select e from com.cognizant.ormlearn.model.Employee e left join fetch e.department d left join fetch e.skillList where e.permanent=1")
List<Employee> getAllPermanentEmployees();
@Query(value="select avg(e.salary) from com.cognizant.ormlearn.model.Employee e where e.department.id = :id")
double getAverageSalary(@Param("id") int id);
@Query(value="select * from employee", nativeQuery=true)
List<Employee> getAllEmployeeNative();
}
